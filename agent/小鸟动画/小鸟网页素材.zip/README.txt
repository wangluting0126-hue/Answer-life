小鸟情绪素材包
================

共 9 只鸟，每只两个动作：点头(nod)、跳跃(jump)，18 个 GIF。

情绪对应：
  开心   蓝紫燕子     rainbow-swallow
  期待   彩色鸳鸯     mandarin-duck
  平静   绿色绣眼鸟   green-white-eye
  疲惫   白色猫头鹰   owl
  焦虑   玄凤鹦鹉     cockatiel
  委屈   白色长尾山雀 white-bush-tit
  生气   灰文鸟       java-sparrow
  难过   蓝山雀       blue-tit
  彩蛋   桃脸牡丹鹦鹉 lovebird

命名：<bird>-nod.gif / <bird>-jump.gif
